<?php
session_start();
require_once("config.php");
?>
<html>
<body>
<?php
include('cadre.php');
?>
<div class="corp">
</div>
</body>
</html>
